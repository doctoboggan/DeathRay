Notes for downloading pythonlabtools and release 323

$Id: README.txt 324 2011-04-07 14:32:25Z mendenhall $

Marcus Mendenhall
7 April, 2011

Vanderbilt University Department of Electrical Engineering and Computer Science

I have converted the whole repository to SVN, and am providing a tarball of the 
contents as they currently stand.  This only changes occasionally, and I generally
recommend directly accessing the project via subversion.
