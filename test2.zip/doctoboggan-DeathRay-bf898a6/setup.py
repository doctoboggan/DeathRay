#!/usr/bin/python -d

from distutils.core import setup
import py2exe

setup(console=['deathray.py'])
