import getvoltageDC 
import getvoltageAC 
import getcurrentDC 
