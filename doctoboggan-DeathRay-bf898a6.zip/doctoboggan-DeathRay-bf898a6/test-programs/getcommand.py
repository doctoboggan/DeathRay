# Here, we should be able to get the right commands for given device

import __init__

class check():

  def __init__(self, namdev):

    self.name_of_device = namdev.lower()




  def 




# way to write the GUI:
'''
1) ask the user the IP address
2) run "getdevice" to get the avialble devices and their gpib addresses. 
3) run "checkinit" to check __init__ file in the module folder. 
4) run "getcommand"
